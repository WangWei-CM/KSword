#pragma once
#include "..\..\KswordTotalHead.h"
void KswordProcManager();