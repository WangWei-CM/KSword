#pragma once
int avkill();