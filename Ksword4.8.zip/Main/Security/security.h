#pragma once
int PasswordVariety();