#include "../../KswordTotalHead.h"
using namespace std;
std::vector<std::pair<HWND, std::string>> g_windows;
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam) {
	DWORD processId = 0;
	GetWindowThreadProcessId(hwnd, &processId);
	if (processId == (DWORD)lParam) {
		char windowTitle[256];
		GetWindowTextA(hwnd, windowTitle, sizeof(windowTitle));
		g_windows.push_back(std::make_pair(hwnd, std::string(windowTitle)));
	}
	return TRUE;
}
BOOL CALLBACK EnumWindowsProcOnScreen(HWND hwnd, LPARAM lParam) {
    // ��ȡ���ڱ���
    const int titleSize = 256;
    WCHAR title[titleSize];
    GetWindowText(hwnd, title, titleSize);
    string a=WCharToString(title);
    // ��鴰���Ƿ�ɼ�
    if (IsWindowVisible(hwnd)) {
        DWORD pid;
        GetWindowThreadProcessId(hwnd,&pid);
        string ImName = GetProcessNameByPID(pid);
        if (ImName.size() >= 12 && ImName.compare(0, 12, "explorer.exe") != 0) {
            cprint("Proc:", 1, 0);
            cout << ImName /*<< ImName << ImName*/ << "(" << pid << ")\t";
            cprint("Title:", 2, 0); cout << a << endl;
        }
    }
    return TRUE; // ����TRUE�Լ�������
}