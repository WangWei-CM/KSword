#pragma once
#include "KswordTotalHead.h"
using namespace std;
int KswordMainHelp();