#pragma once
#include <iphlpapi.h>
#pragma comment(lib, "iphlpapi.lib")
#include "KswordTotalHead.h"
void KswordNetManager();
void KswordKeepKillTCP(int,int);