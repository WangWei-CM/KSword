#ifndef Ksword_Main_1
#define Ksword_Main_1

#include "..\Main\KswordTotalHead.h"
bool KReceiverContinue = 1;
bool IsKMain1Mini = 0;
int showSecond = 0;
bool shouldShowWindow = 0;
void KswordMain1ShowManager() {
	while (IsKMain1Mini) {
		if (showSecond > 0) {
			--showSecond;  // ��ȥ 1
			std::this_thread::sleep_for(std::chrono::seconds(1));  // �ȴ� 1 ��
		}
		if (showSecond == 0) {
			HideWindow();
			shouldShowWindow = 1;
		}
		else if (showSecond > 0) {
			if (shouldShowWindow) {
				ShowWindow();
				shouldShowWindow = 0;
			}
		}
		std::this_thread::sleep_for(std::chrono::milliseconds(100));
	}
}


void KswordMain1SetMini() {
	int WindowX = ScreenX - 20 * fontWidth - K_DEFAULT_SPACE - 50;
	int WindowY = ScreenY - GetSystemMetrics(SM_CYCAPTION) - K_DEFAULT_SPACE - 3 * fontHeight;
	SetConsoleWindowPosition(WindowX, WindowY);
	SetConsoleWindowSize(20, 3);
}

void KswordMain1SetMax() {
	SetConsoleWindowPosition(RightColumnStartLocationX, RightColumnStartLocationY);
	SetConsoleWindowSize(ColumnWidth, ColumnHeight);
}
int KswordMain1(char* argv) {

	AllocConsole();
	//SetConsoleOutputCP(CP_UTF8);
	//SetConsola();
	//system("color 97");
	DWORD exStyle = GetWindowLong(GetConsoleWindow(), GWL_EXSTYLE);
	exStyle |= WS_EX_TRANSPARENT;
	SetWindowLong(GetConsoleWindow(), GWL_EXSTYLE, exStyle);
	SetWindowPos(GetConsoleWindow(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
	SetAir(200);
	HideSide();
	Sleep(50);
	SetConsoleWindowPosition(RightColumnStartLocationX, RightColumnStartLocationY);
	SetConsoleWindowSize(ColumnWidth, ColumnHeight+7);	
	LONG_PTR currentExStyle = GetWindowLongPtr(GetConsoleWindow(), GWL_EXSTYLE);
	SetWindowLongPtr(GetConsoleWindow(), GWL_EXSTYLE, currentExStyle | WS_EX_TOOLWINDOW);
	std::thread listenerThread(keyboardListener);
	KMesInfo("�ӽ���1�ɹ�����");
	const std::string pipeName = "\\\\.\\pipe\\Ksword_Pipe_1_"+string(argv);
	SetWindowText(GetConsoleWindow(), L"KswordͨѶ������");
	char buffer[256];
	DWORD bytesRead;
	HANDLE hPipe;
	//Sleep(500);
	SetTopWindow();
	// �������ܵ�
	hPipe = CreateFile(
		CharToWChar(pipeName.c_str()),
		GENERIC_READ,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL
	);
	KswordSend1("sub1");
	if (hPipe == INVALID_HANDLE_VALUE) {
		KMesErr("�޷���ͨ�������򼴽��˳�");
		exit(1);
	}
	if (!SetTopWindow()) {
		KMesErr("�ö�ʧ��");
	}
	// ��ȡ��Ϣ
	while (KReceiverContinue) {
		std::string line;
		while (true) {
			char ch;
			BOOL success = ReadFile(
				hPipe,
				&ch,
				1, // ÿ��ֻ��ȡһ���ֽ�
				&bytesRead,
				NULL
			);

			if (!success || bytesRead == 0) {
				KMesErr("�޷��ӹܵ��л�ȡ����");
				CloseHandle(hPipe);
				exit(1);
			}

			if (ch == '\n'||ch=='`') { // �����ȡ�����з���ֹͣ��ȡ
				break;
			}

			line += ch; // ���ַ�׷�ӵ��ַ�����
		}
		buffer[bytesRead] = '\0'; // ȷ���ַ����Կ��ַ���β

		KPrintTime();
		std::cout << line<< std::endl;
		if(!strcmp(line.c_str(), "refresh")) {
			KMain1Refresh();
		}
		else if (!strcmp(line.c_str(), "show")) {
			//IsKMain1Mini = 0;
			ShowWindow();
		}
		else if (!strcmp(line.c_str(), "hide")) {
			//cout << "�����ж�";
			//KswordMain1SetMini();
			//thread t(KswordMain1ShowManager);
			//IsKMain1Mini = 1;
			HideWindow();
		}
		else {
			KReceiverContinue = 1;
		}
	}
	// �رչܵ�
	CloseHandle(hPipe);
	FreeConsole();
	return 0;
}



void KMain1Refresh() {
	SetAir(200);
	HideSide();
	SetConsoleWindowPosition(RightColumnStartLocationX, RightColumnStartLocationY);
	SetConsoleWindowSize(ColumnWidth, ColumnHeight);
}

#endif