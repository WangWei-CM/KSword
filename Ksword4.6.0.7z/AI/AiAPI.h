#pragma once
#include "..\Main\KswordTotalHead.h"

void KimiAPI(string post, string API_KEY);