#ifndef Ksword_Main_1
#define Ksword_Main_1

#include "ksword.h"
#include "KswordCUIManager.h"
#include "MainSupportFunction.h"
#include "KswordSelfSocket.h"
bool KReceiverContinue = 1;

int KswordMain1(char* argv) {
	
	AllocConsole();
	SetConsola();
	//system("color 97");
	DWORD exStyle = GetWindowLong(GetConsoleWindow(), GWL_EXSTYLE);

	// ���ӵ����͸��ʽ
	exStyle |= WS_EX_TRANSPARENT;

	// Ӧ���µ���չ��ʽ
	SetWindowLong(GetConsoleWindow(), GWL_EXSTYLE, exStyle);

	// ���´�����Ӧ�ø���
	SetWindowPos(GetConsoleWindow(), nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
	SetAir(200);
	HideSide();
	SetConsoleWindowPosition(RightColumnStartLocationX, RightColumnStartLocationY);
	SetConsoleWindowSize(ColumnWidth, ColumnHeight);	
	std::thread listenerThread(keyboardListener);
	KMesInfo("�ӽ���1�ɹ�����");
	const std::string pipeName = "\\\\.\\pipe\\Ksword_Pipe_1_"+string(argv);
	char buffer[256];
	DWORD bytesRead;
	HANDLE hPipe;
	//Sleep(500);
	SetTopWindow();
	// �������ܵ�
	hPipe = CreateFile(
		CharToWChar(pipeName.c_str()),
		GENERIC_READ,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL
	);
	KswordSend1("sub1");
	if (hPipe == INVALID_HANDLE_VALUE) {
		KMesErr("�޷���ͨ�������򼴽��˳�");
		return 1;
	}

	// ��ȡ��Ϣ
	while (KReceiverContinue) {

		BOOL success = ReadFile(
			hPipe,
			buffer,
			sizeof(buffer) - 1,
			&bytesRead,
			NULL
		);

		if (!success) {
			KMesErr("�޷��ӹܵ��л�ȡ����");
			CloseHandle(hPipe);
			exit(0);
		}
		buffer[bytesRead] = '\0'; // ȷ���ַ����Կ��ַ���β

		if (strcmp(buffer, "exit")!=0) {
		KPrintTime();
		std::cout << buffer << std::endl;
		}
		else {
			KReceiverContinue = 0;
		}

	}
	// �رչܵ�
	CloseHandle(hPipe);
	FreeConsole();
	return 0;
}
#endif