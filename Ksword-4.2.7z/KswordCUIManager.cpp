#include "ksword.h"
#include "KswordCUIManager.h"
#define CONSOLE_FONT_HEIGHT 18
#define CONSOLE_FONT_WIDTH 8
using namespace std;
int LeftColumnStartLocationX = 20;
int LeftColumnStartLocationY = 20;
int RightColumnStartLocationX = 0;
int RightColumnStartLocationY = 20;
int ColumnWidth = 0;
int ColumnHeight = 0;
void CalcWindowStyle() {
	KEnviProb();
	RightColumnStartLocationX = ScreenX / 2 + 10;
	ColumnWidth = (ScreenX / 2 - 20) / CONSOLE_FONT_WIDTH;
	ColumnHeight = (ScreenY * 3 / 4) / CONSOLE_FONT_HEIGHT;
	return;
}




