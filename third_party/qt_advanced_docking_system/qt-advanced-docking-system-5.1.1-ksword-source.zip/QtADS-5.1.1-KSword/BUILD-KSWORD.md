# Build the modified ADS shared library

This source accompanies the KSword-modified ADS 5.1.1 DLL (LGPL-2.1-or-later).
All C++ library modules, resources, interfaces and CMake files are included.
Unused demonstrations, documentation media and Python bindings are not linked
into this DLL. Original license and copyright notices remain in the sources.
The one modified source file has a prominent modification/date notice.

Extract this ZIP and run PowerShell from the directory containing src/:

```powershell
$sourceRoot = (Get-Location).Path
$env:KSWORD_QT_DIR = 'path/to/Qt/6.9.3/msvc2022_64'
$msbuild = 'path/to/VisualStudio/MSBuild/Current/Bin/amd64/MSBuild.exe'
if (!(Test-Path $msbuild)) { throw '64-bit MSBuild is required.' }
cmake -S ksword-build -B build -G 'Visual Studio 17 2022' -A x64 -T host=x64 `
  "-DCMAKE_PREFIX_PATH=$env:KSWORD_QT_DIR" "-DKSWORD_ADS_SOURCE_DIR=$sourceRoot"
$project = 'build/upstream/src/qtadvanceddocking-qt6.vcxproj'
$hostArgs = @('/p:Platform=x64', '/p:PreferredToolArchitecture=x64', '/p:PROCESSOR_ARCHITECTURE=AMD64', '/p:PROCESSOR_ARCHITEW6432=AMD64')
& $msbuild $project /t:Build /p:Configuration=Release @hostArgs /m:1 /v:minimal
& $msbuild $project /t:Build /p:Configuration=Debug @hostArgs /m:1 /v:minimal
```

The patch is already applied. See ksword-build/NOTICE.md for upstream identity.
CMake verifies the distributed source revision to reproduce the shipped build.
When intentionally modifying ADS, update that source-hash check as well.
This build-time identity check is not a runtime DLL replacement restriction.
Use an interface-compatible DLL to replace qtadvanceddocking.dll next to the
application. Preserve its x64, Qt6.9.3, MSVC ABI and Release/Debug CRT settings.
The public headers and exported interfaces were not changed by this patch.
