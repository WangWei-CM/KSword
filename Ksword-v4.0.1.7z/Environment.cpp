#include "ksword.h"
#include "Environment.h"
std::string AuthName;
std::string HostName;
std::string ExePath;
bool IsAuthAdmin;
void KEnviProb() {
	AuthName = GetUserName();
	HostName = GetHostName();
	IsAuthAdmin = IsAdmin();
	ExePath = GetSelfPath();
}