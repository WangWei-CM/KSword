#pragma once
#ifndef KSWORD_CUI_MANAGER_HEAD
#define KSWORD_CUI_MANAGER_HEAD

#include "ksword.h"
#include "Environment.h"
extern int LeftColumnStartLocationX;
extern int LeftColumnStartLocationY;
extern int RightColumnStartLocationX;
extern int RightColumnStartLocationY;
extern int ColumnWidth;
extern int ColumnHeight;
extern void CalcWindowStyle();


#endif // !KSWORD_CUI_MANAGER_HEAD
