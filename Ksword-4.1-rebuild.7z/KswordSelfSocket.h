//#pragma once
#ifndef KSWORD_SELFSOCKET_HEAD
#define KSWORD_SELFSOCKET_HEAD

#include "ksword.h"

using namespace std;

extern int KswordMain1();
extern int KswordSelfProc1();
extern int KswordSelfPipe1();
extern int KswordSend1(string);
extern int KswordSend1(const char*);
#endif // !KSWORD_SELFSOCKET_HEAD
